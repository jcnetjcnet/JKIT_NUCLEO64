/*
 * fnd.c
 *
 *  Created on: 2020. 2. 26.
 *      Author: isjeon
 */

#include "main.h"

void fnd_fn(int ac, char *av[])
{
         static int fnd_sel = 0;
          int i;
          for(fnd_sel = 0 ; fnd_sel < 4 ; fnd_sel ++)
          {
        	  switch(fnd_sel)
        	  {
          	  case 0 :
                  FND_SEL0_GPIO_Port->BSRR = FND_SEL0_Pin;
                  FND_SEL1_GPIO_Port->BRR  = FND_SEL1_Pin;
                  FND_SEL2_GPIO_Port->BRR  = FND_SEL2_Pin;
                  FND_SEL3_GPIO_Port->BRR  = FND_SEL3_Pin;
                  break;
          	  case 1 :
                  FND_SEL0_GPIO_Port->BRR  = FND_SEL0_Pin;
                  FND_SEL1_GPIO_Port->BSRR  = FND_SEL1_Pin;
                  FND_SEL2_GPIO_Port->BRR  = FND_SEL2_Pin;
                  FND_SEL3_GPIO_Port->BRR  = FND_SEL3_Pin;
                  break;
          	  case 2 :
                  FND_SEL0_GPIO_Port->BRR  = FND_SEL0_Pin;
                  FND_SEL1_GPIO_Port->BRR  = FND_SEL1_Pin;
                  FND_SEL2_GPIO_Port->BSRR  = FND_SEL2_Pin;
                  FND_SEL3_GPIO_Port->BRR  = FND_SEL3_Pin;
                  break;
          	  case 3 :
                  FND_SEL0_GPIO_Port->BRR  = FND_SEL0_Pin;
                  FND_SEL1_GPIO_Port->BRR  = FND_SEL1_Pin;
                  FND_SEL2_GPIO_Port->BRR  = FND_SEL2_Pin;
                  FND_SEL3_GPIO_Port->BSRR  = FND_SEL3_Pin;
                  break;
          	  }
          	  for( i = 0 ; i < 8 ; i ++)
          	  {
                  GPIOA->ODR = (1 << i) << 4; // PA4~PA11
                  HAL_Delay(100);
          	  }
          }
          FND_SEL0_GPIO_Port->BRR  = FND_SEL0_Pin;
          FND_SEL1_GPIO_Port->BRR  = FND_SEL1_Pin;
          FND_SEL2_GPIO_Port->BRR  = FND_SEL2_Pin;
          FND_SEL3_GPIO_Port->BRR  = FND_SEL3_Pin;
  }
