/*
 * sub_fn.c
 *
 *  Created on: 2020. 2. 26.
 *      Author: isjeon
 */

#include "main.h"

void led_fn(int ac, char *av[])
{
    uint32_t led;
    int i;
    printf("LED..\n");
    led = 1;
    for( i = 0 ; i < 8 ; i ++, led <<= 1)
    {
            GPIOB->ODR = (GPIOB->ODR & ~(0xf << 12)) | ((led & 0xf) << 12);
            GPIOC->ODR = (GPIOC->ODR & ~(0xf << 0 )) | ((led & 0xf0) >> 4);
            HAL_Delay(500);
    }
    led = 0;
    GPIOB->ODR = (GPIOB->ODR & ~(0xf << 12)) | ((led & 0xf) << 12);
    GPIOC->ODR = (GPIOC->ODR & ~(0xf << 0 )) | ((led & 0xf0) >> 4);
}

void temp_fn(int ac, char *av[])
{

}

void switch_fn(int ac, char *av[])
{
	uint32_t prev,flag = 0;
	prev = HAL_GetTick();
	while(1)
	{
		 if(!(SW2_GPIO_Port->IDR & SW2_Pin))
		 {
			 printf("SW2 pushed\n");
			 while(!(SW2_GPIO_Port->IDR & SW2_Pin))
			 { if(HAL_GetTick() - prev >= 5000) return;}
			 prev = HAL_GetTick();
			 flag ++;
		 }
		 if(!(SW1_GPIO_Port->IDR & SW1_Pin))
		 {
				 printf("SW1 pushed\n");
				 while(!(SW1_GPIO_Port->IDR & SW1_Pin))
				 {
					 if(HAL_GetTick() - prev >= 5000) return;
				 }
				 prev = HAL_GetTick();
				 flag ++;
		 }
		 if(flag >= 2)
		 {
			 buz_fn(ac,av);
			 return;
		 }

	}
}

void motor_fn(int ac, char *av[])
{

}
void fatfs_fn(int ac, char *av[])
{
	  fatfs_test(0);
}
void run_all(int ac, char *av[])
{
	led_fn(ac,av);
	fnd_fn(ac,av);
	clcd_fn(ac,av);
	buz_fn(ac,av);
	cds_fn(ac,av);
	switch_fn(ac,av);
}
